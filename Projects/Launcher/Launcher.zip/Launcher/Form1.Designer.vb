﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.OUT = New System.Windows.Forms.TextBox()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.NsGroupBox4 = New Launcher.NSGroupBox()
        Me.btn_Play2 = New Launcher.ButtonBlue()
        Me.Button2 = New Launcher.ButtonBlue()
        Me.btn_Play1 = New Launcher.ButtonBlue()
        Me.NsGroupBox1 = New Launcher.NSGroupBox()
        Me.NsLabel2 = New Launcher.NSLabel()
        Me.NsProgressBar1 = New Launcher.NSProgressBar()
        Me.NsLabel1 = New Launcher.NSLabel()
        Me.NsTabControl1 = New Launcher.NSTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.KachClazz1 = New Launcher.KachClazz()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NsGroupBox5 = New Launcher.NSGroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NsTextBox2 = New Launcher.NSTextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.gb_AU = New Launcher.NSGroupBox()
        Me.tb_UserPass = New Launcher.NSTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.NsCheckBox1 = New Launcher.NSCheckBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NsButton3 = New Launcher.NSButton()
        Me.NsLabel5 = New Launcher.NSLabel()
        Me.NsButton2 = New Launcher.NSButton()
        Me.NsLabel4 = New Launcher.NSLabel()
        Me.NsButton1 = New Launcher.NSButton()
        Me.NsTextBox1 = New Launcher.NSTextBox()
        Me.NsLabel3 = New Launcher.NSLabel()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.NsButton6 = New Launcher.NSButton()
        Me.NsButton5 = New Launcher.NSButton()
        Me.NsButton4 = New Launcher.NSButton()
        Me.lbl_AddOn = New System.Windows.Forms.Label()
        Me.NsGroupBox2 = New Launcher.NSGroupBox()
        Me.NsSeperator1 = New Launcher.NSSeperator()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.WMP = New AxWMPLib.AxWindowsMediaPlayer()
        Me.NsButton9 = New Launcher.NSButton()
        Me.NsButton8 = New Launcher.NSButton()
        Me.NsButton7 = New Launcher.NSButton()
        Me.NsGroupBox3 = New Launcher.NSGroupBox()
        Me.NsSeperator2 = New Launcher.NSSeperator()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.NsGroupBox4.SuspendLayout()
        Me.NsGroupBox1.SuspendLayout()
        Me.NsTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.NsGroupBox5.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.gb_AU.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.NsGroupBox2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WMP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NsGroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Timer2
        '
        Me.Timer2.Interval = 1000
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(736, 247)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(32, 10)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        Me.TextBox1.Visible = False
        '
        'OUT
        '
        Me.OUT.Location = New System.Drawing.Point(736, 263)
        Me.OUT.Name = "OUT"
        Me.OUT.Size = New System.Drawing.Size(32, 22)
        Me.OUT.TabIndex = 4
        Me.OUT.Visible = False
        '
        'Timer3
        '
        Me.Timer3.Interval = 3000
        '
        'NsGroupBox4
        '
        Me.NsGroupBox4.Controls.Add(Me.btn_Play2)
        Me.NsGroupBox4.Controls.Add(Me.Button2)
        Me.NsGroupBox4.Controls.Add(Me.btn_Play1)
        Me.NsGroupBox4.DrawSeperator = False
        Me.NsGroupBox4.Location = New System.Drawing.Point(444, 319)
        Me.NsGroupBox4.Name = "NsGroupBox4"
        Me.NsGroupBox4.Size = New System.Drawing.Size(114, 115)
        Me.NsGroupBox4.SubTitle = ""
        Me.NsGroupBox4.TabIndex = 3
        Me.NsGroupBox4.Text = "NsGroupBox4"
        Me.NsGroupBox4.Title = ""
        '
        'btn_Play2
        '
        Me.btn_Play2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Play2.Font = New System.Drawing.Font("Franklin Gothic Book", 14.0!)
        Me.btn_Play2.Image = Nothing
        Me.btn_Play2.Location = New System.Drawing.Point(9, 9)
        Me.btn_Play2.Name = "btn_Play2"
        Me.btn_Play2.NoRounding = False
        Me.btn_Play2.Size = New System.Drawing.Size(97, 55)
        Me.btn_Play2.TabIndex = 6
        Me.btn_Play2.Text = "Spielen"
        Me.btn_Play2.Visible = False
        '
        'Button2
        '
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Book", 14.0!)
        Me.Button2.Image = Nothing
        Me.Button2.Location = New System.Drawing.Point(9, 70)
        Me.Button2.Name = "Button2"
        Me.Button2.NoRounding = False
        Me.Button2.Size = New System.Drawing.Size(97, 38)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Beenden"
        '
        'btn_Play1
        '
        Me.btn_Play1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Play1.Font = New System.Drawing.Font("Franklin Gothic Book", 14.0!)
        Me.btn_Play1.Image = Nothing
        Me.btn_Play1.Location = New System.Drawing.Point(9, 9)
        Me.btn_Play1.Name = "btn_Play1"
        Me.btn_Play1.NoRounding = False
        Me.btn_Play1.Size = New System.Drawing.Size(97, 55)
        Me.btn_Play1.TabIndex = 4
        Me.btn_Play1.Text = "Spielen"
        '
        'NsGroupBox1
        '
        Me.NsGroupBox1.Controls.Add(Me.NsLabel2)
        Me.NsGroupBox1.Controls.Add(Me.NsProgressBar1)
        Me.NsGroupBox1.Controls.Add(Me.NsLabel1)
        Me.NsGroupBox1.DrawSeperator = False
        Me.NsGroupBox1.Location = New System.Drawing.Point(12, 319)
        Me.NsGroupBox1.Name = "NsGroupBox1"
        Me.NsGroupBox1.Size = New System.Drawing.Size(426, 115)
        Me.NsGroupBox1.SubTitle = ""
        Me.NsGroupBox1.TabIndex = 3
        Me.NsGroupBox1.Text = "NsGroupBox1"
        Me.NsGroupBox1.Title = ""
        '
        'NsLabel2
        '
        Me.NsLabel2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel2.Location = New System.Drawing.Point(12, 74)
        Me.NsLabel2.Name = "NsLabel2"
        Me.NsLabel2.Size = New System.Drawing.Size(175, 20)
        Me.NsLabel2.TabIndex = 2
        Me.NsLabel2.Text = "NsLabel2"
        Me.NsLabel2.Value1 = "0 MB |"
        Me.NsLabel2.Value2 = " 0 MB"
        '
        'NsProgressBar1
        '
        Me.NsProgressBar1.Location = New System.Drawing.Point(12, 41)
        Me.NsProgressBar1.Maximum = 100
        Me.NsProgressBar1.Minimum = 0
        Me.NsProgressBar1.Name = "NsProgressBar1"
        Me.NsProgressBar1.Size = New System.Drawing.Size(399, 23)
        Me.NsProgressBar1.TabIndex = 1
        Me.NsProgressBar1.Text = "NsProgressBar1"
        Me.NsProgressBar1.Value = 0
        '
        'NsLabel1
        '
        Me.NsLabel1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel1.Location = New System.Drawing.Point(12, 15)
        Me.NsLabel1.Name = "NsLabel1"
        Me.NsLabel1.Size = New System.Drawing.Size(175, 20)
        Me.NsLabel1.TabIndex = 0
        Me.NsLabel1.Text = "NsLabel1"
        Me.NsLabel1.Value1 = "Fortschritt:"
        Me.NsLabel1.Value2 = " 0 %"
        '
        'NsTabControl1
        '
        Me.NsTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.NsTabControl1.Controls.Add(Me.TabPage1)
        Me.NsTabControl1.Controls.Add(Me.TabPage2)
        Me.NsTabControl1.Controls.Add(Me.TabPage3)
        Me.NsTabControl1.Controls.Add(Me.TabPage4)
        Me.NsTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.NsTabControl1.ItemSize = New System.Drawing.Size(28, 115)
        Me.NsTabControl1.Location = New System.Drawing.Point(12, 12)
        Me.NsTabControl1.Multiline = True
        Me.NsTabControl1.Name = "NsTabControl1"
        Me.NsTabControl1.SelectedIndex = 0
        Me.NsTabControl1.Size = New System.Drawing.Size(545, 301)
        Me.NsTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.NsTabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.KachClazz1)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.NsGroupBox5)
        Me.TabPage1.Controls.Add(Me.NsTextBox2)
        Me.TabPage1.Controls.Add(Me.PictureBox2)
        Me.TabPage1.Location = New System.Drawing.Point(119, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(422, 293)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Startseite"
        '
        'KachClazz1
        '
        Me.KachClazz1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KachClazz1.Location = New System.Drawing.Point(334, 6)
        Me.KachClazz1.Name = "KachClazz1"
        Me.KachClazz1.Size = New System.Drawing.Size(75, 23)
        Me.KachClazz1.TabIndex = 14
        Me.KachClazz1.Text = "KachClazz1"
        Me.KachClazz1.Value1 = "Version:"
        Me.KachClazz1.Value2 = " 1.2.1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Silver
        Me.Label4.Location = New System.Drawing.Point(20, 118)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Label4"
        '
        'NsGroupBox5
        '
        Me.NsGroupBox5.Controls.Add(Me.Label8)
        Me.NsGroupBox5.Controls.Add(Me.Label7)
        Me.NsGroupBox5.Controls.Add(Me.Label6)
        Me.NsGroupBox5.Controls.Add(Me.Label5)
        Me.NsGroupBox5.DrawSeperator = False
        Me.NsGroupBox5.Location = New System.Drawing.Point(6, 240)
        Me.NsGroupBox5.Name = "NsGroupBox5"
        Me.NsGroupBox5.Size = New System.Drawing.Size(410, 47)
        Me.NsGroupBox5.SubTitle = ""
        Me.NsGroupBox5.TabIndex = 12
        Me.NsGroupBox5.Text = "NsGroupBox5"
        Me.NsGroupBox5.Title = ""
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Lime
        Me.Label8.Location = New System.Drawing.Point(302, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 17)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Online"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Lime
        Me.Label7.Location = New System.Drawing.Point(148, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Online"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Silver
        Me.Label6.Location = New System.Drawing.Point(207, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 17)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "World Server:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Silver
        Me.Label5.Location = New System.Drawing.Point(61, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Auth Server:"
        '
        'NsTextBox2
        '
        Me.NsTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NsTextBox2.Enabled = False
        Me.NsTextBox2.Location = New System.Drawing.Point(6, 102)
        Me.NsTextBox2.MaxLength = 32767
        Me.NsTextBox2.Multiline = False
        Me.NsTextBox2.Name = "NsTextBox2"
        Me.NsTextBox2.ReadOnly = False
        Me.NsTextBox2.Size = New System.Drawing.Size(410, 116)
        Me.NsTextBox2.TabIndex = 13
        Me.NsTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.NsTextBox2.UseSystemPasswordChar = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(92, -13)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(215, 130)
        Me.PictureBox2.TabIndex = 10
        Me.PictureBox2.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.gb_AU)
        Me.TabPage2.Controls.Add(Me.NsCheckBox1)
        Me.TabPage2.Controls.Add(Me.PictureBox1)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.NsButton3)
        Me.TabPage2.Controls.Add(Me.NsLabel5)
        Me.TabPage2.Controls.Add(Me.NsButton2)
        Me.TabPage2.Controls.Add(Me.NsLabel4)
        Me.TabPage2.Controls.Add(Me.NsButton1)
        Me.TabPage2.Controls.Add(Me.NsTextBox1)
        Me.TabPage2.Controls.Add(Me.NsLabel3)
        Me.TabPage2.Location = New System.Drawing.Point(119, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(422, 293)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Einstellungen"
        '
        'gb_AU
        '
        Me.gb_AU.Controls.Add(Me.tb_UserPass)
        Me.gb_AU.Controls.Add(Me.Label9)
        Me.gb_AU.DrawSeperator = False
        Me.gb_AU.Enabled = False
        Me.gb_AU.Location = New System.Drawing.Point(19, 186)
        Me.gb_AU.Name = "gb_AU"
        Me.gb_AU.Size = New System.Drawing.Size(184, 90)
        Me.gb_AU.SubTitle = ""
        Me.gb_AU.TabIndex = 11
        Me.gb_AU.Text = "NsGroupBox6"
        Me.gb_AU.Title = ""
        '
        'tb_UserPass
        '
        Me.tb_UserPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.tb_UserPass.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_UserPass.Location = New System.Drawing.Point(17, 45)
        Me.tb_UserPass.MaxLength = 32767
        Me.tb_UserPass.Multiline = False
        Me.tb_UserPass.Name = "tb_UserPass"
        Me.tb_UserPass.ReadOnly = False
        Me.tb_UserPass.Size = New System.Drawing.Size(154, 27)
        Me.tb_UserPass.TabIndex = 1
        Me.tb_UserPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.tb_UserPass.UseSystemPasswordChar = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label9.Location = New System.Drawing.Point(14, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 17)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Passwort:"
        '
        'NsCheckBox1
        '
        Me.NsCheckBox1.Checked = False
        Me.NsCheckBox1.Location = New System.Drawing.Point(21, 157)
        Me.NsCheckBox1.Name = "NsCheckBox1"
        Me.NsCheckBox1.Size = New System.Drawing.Size(182, 23)
        Me.NsCheckBox1.TabIndex = 10
        Me.NsCheckBox1.Text = " Verwende Auto Login"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(221, 157)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(195, 119)
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(196, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 21)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "OK"
        Me.Label2.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(196, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 21)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "OK"
        Me.Label1.Visible = False
        '
        'NsButton3
        '
        Me.NsButton3.Location = New System.Drawing.Point(112, 107)
        Me.NsButton3.Name = "NsButton3"
        Me.NsButton3.Size = New System.Drawing.Size(78, 33)
        Me.NsButton3.TabIndex = 6
        Me.NsButton3.Text = "  Löschen"
        '
        'NsLabel5
        '
        Me.NsLabel5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel5.Location = New System.Drawing.Point(19, 107)
        Me.NsLabel5.Name = "NsLabel5"
        Me.NsLabel5.Size = New System.Drawing.Size(73, 23)
        Me.NsLabel5.TabIndex = 5
        Me.NsLabel5.Text = "NsLabel5"
        Me.NsLabel5.Value1 = "Spiel "
        Me.NsLabel5.Value2 = " Config"
        '
        'NsButton2
        '
        Me.NsButton2.Location = New System.Drawing.Point(112, 63)
        Me.NsButton2.Name = "NsButton2"
        Me.NsButton2.Size = New System.Drawing.Size(78, 33)
        Me.NsButton2.TabIndex = 4
        Me.NsButton2.Text = "  Löschen"
        '
        'NsLabel4
        '
        Me.NsLabel4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel4.Location = New System.Drawing.Point(20, 63)
        Me.NsLabel4.Name = "NsLabel4"
        Me.NsLabel4.Size = New System.Drawing.Size(72, 23)
        Me.NsLabel4.TabIndex = 3
        Me.NsLabel4.Text = "NsLabel4"
        Me.NsLabel4.Value1 = "Spiel "
        Me.NsLabel4.Value2 = " Cache"
        '
        'NsButton1
        '
        Me.NsButton1.Location = New System.Drawing.Point(307, 63)
        Me.NsButton1.Name = "NsButton1"
        Me.NsButton1.Size = New System.Drawing.Size(90, 33)
        Me.NsButton1.TabIndex = 2
        Me.NsButton1.Text = "  Speichern"
        '
        'NsTextBox1
        '
        Me.NsTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NsTextBox1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsTextBox1.Location = New System.Drawing.Point(128, 18)
        Me.NsTextBox1.MaxLength = 32767
        Me.NsTextBox1.Multiline = False
        Me.NsTextBox1.Name = "NsTextBox1"
        Me.NsTextBox1.ReadOnly = False
        Me.NsTextBox1.Size = New System.Drawing.Size(269, 27)
        Me.NsTextBox1.TabIndex = 1
        Me.NsTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.NsTextBox1.UseSystemPasswordChar = False
        '
        'NsLabel3
        '
        Me.NsLabel3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel3.Location = New System.Drawing.Point(21, 18)
        Me.NsLabel3.Name = "NsLabel3"
        Me.NsLabel3.Size = New System.Drawing.Size(101, 23)
        Me.NsLabel3.TabIndex = 0
        Me.NsLabel3.Text = "NsLabel3"
        Me.NsLabel3.Value1 = "Server"
        Me.NsLabel3.Value2 = " Realmlist"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.NsButton6)
        Me.TabPage3.Controls.Add(Me.NsButton5)
        Me.TabPage3.Controls.Add(Me.NsButton4)
        Me.TabPage3.Controls.Add(Me.lbl_AddOn)
        Me.TabPage3.Controls.Add(Me.NsGroupBox2)
        Me.TabPage3.Location = New System.Drawing.Point(119, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(422, 293)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "AddOns"
        '
        'NsButton6
        '
        Me.NsButton6.Location = New System.Drawing.Point(283, 106)
        Me.NsButton6.Name = "NsButton6"
        Me.NsButton6.Size = New System.Drawing.Size(115, 33)
        Me.NsButton6.TabIndex = 5
        Me.NsButton6.Text = " AddOn Löschen"
        '
        'NsButton5
        '
        Me.NsButton5.Location = New System.Drawing.Point(283, 67)
        Me.NsButton5.Name = "NsButton5"
        Me.NsButton5.Size = New System.Drawing.Size(115, 33)
        Me.NsButton5.TabIndex = 4
        Me.NsButton5.Text = " Backup Erstellen"
        '
        'NsButton4
        '
        Me.NsButton4.Location = New System.Drawing.Point(283, 28)
        Me.NsButton4.Name = "NsButton4"
        Me.NsButton4.Size = New System.Drawing.Size(115, 33)
        Me.NsButton4.TabIndex = 3
        Me.NsButton4.Text = "   Ordner Öffen"
        '
        'lbl_AddOn
        '
        Me.lbl_AddOn.AutoSize = True
        Me.lbl_AddOn.Location = New System.Drawing.Point(346, 221)
        Me.lbl_AddOn.Name = "lbl_AddOn"
        Me.lbl_AddOn.Size = New System.Drawing.Size(0, 17)
        Me.lbl_AddOn.TabIndex = 2
        Me.lbl_AddOn.Visible = False
        '
        'NsGroupBox2
        '
        Me.NsGroupBox2.Controls.Add(Me.NsSeperator1)
        Me.NsGroupBox2.Controls.Add(Me.ListBox1)
        Me.NsGroupBox2.DrawSeperator = False
        Me.NsGroupBox2.Location = New System.Drawing.Point(16, 17)
        Me.NsGroupBox2.Name = "NsGroupBox2"
        Me.NsGroupBox2.Size = New System.Drawing.Size(250, 255)
        Me.NsGroupBox2.SubTitle = "Details"
        Me.NsGroupBox2.TabIndex = 1
        Me.NsGroupBox2.Text = "NsGroupBox2"
        Me.NsGroupBox2.Title = "Installierte AddOns"
        '
        'NsSeperator1
        '
        Me.NsSeperator1.Location = New System.Drawing.Point(3, 34)
        Me.NsSeperator1.Name = "NsSeperator1"
        Me.NsSeperator1.Size = New System.Drawing.Size(242, 10)
        Me.NsSeperator1.TabIndex = 1
        Me.NsSeperator1.Text = "NsSeperator1"
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.Black
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 17
        Me.ListBox1.Location = New System.Drawing.Point(3, 42)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(242, 204)
        Me.ListBox1.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.TrackBar1)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.WMP)
        Me.TabPage4.Controls.Add(Me.NsButton9)
        Me.TabPage4.Controls.Add(Me.NsButton8)
        Me.TabPage4.Controls.Add(Me.NsButton7)
        Me.TabPage4.Controls.Add(Me.NsGroupBox3)
        Me.TabPage4.Location = New System.Drawing.Point(119, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(422, 293)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Sountrack"
        '
        'TrackBar1
        '
        Me.TrackBar1.Location = New System.Drawing.Point(16, 238)
        Me.TrackBar1.Maximum = 100
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(193, 45)
        Me.TrackBar1.TabIndex = 9
        Me.TrackBar1.TickFrequency = 5
        Me.TrackBar1.Value = 100
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 254)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(17, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "..."
        Me.Label3.Visible = False
        '
        'WMP
        '
        Me.WMP.Enabled = True
        Me.WMP.Location = New System.Drawing.Point(398, 191)
        Me.WMP.Name = "WMP"
        Me.WMP.OcxState = CType(resources.GetObject("WMP.OcxState"), System.Windows.Forms.AxHost.State)
        Me.WMP.Size = New System.Drawing.Size(10, 10)
        Me.WMP.TabIndex = 6
        Me.WMP.Visible = False
        '
        'NsButton9
        '
        Me.NsButton9.Location = New System.Drawing.Point(298, 238)
        Me.NsButton9.Name = "NsButton9"
        Me.NsButton9.Size = New System.Drawing.Size(62, 33)
        Me.NsButton9.TabIndex = 5
        Me.NsButton9.Text = "  Pause"
        Me.NsButton9.Visible = False
        '
        'NsButton8
        '
        Me.NsButton8.Location = New System.Drawing.Point(230, 238)
        Me.NsButton8.Name = "NsButton8"
        Me.NsButton8.Size = New System.Drawing.Size(62, 33)
        Me.NsButton8.TabIndex = 4
        Me.NsButton8.Text = "   Stop"
        '
        'NsButton7
        '
        Me.NsButton7.Location = New System.Drawing.Point(298, 238)
        Me.NsButton7.Name = "NsButton7"
        Me.NsButton7.Size = New System.Drawing.Size(62, 33)
        Me.NsButton7.TabIndex = 3
        Me.NsButton7.Text = "   Play"
        '
        'NsGroupBox3
        '
        Me.NsGroupBox3.Controls.Add(Me.NsSeperator2)
        Me.NsGroupBox3.Controls.Add(Me.ListBox2)
        Me.NsGroupBox3.DrawSeperator = False
        Me.NsGroupBox3.Location = New System.Drawing.Point(16, 17)
        Me.NsGroupBox3.Name = "NsGroupBox3"
        Me.NsGroupBox3.Size = New System.Drawing.Size(392, 215)
        Me.NsGroupBox3.SubTitle = "Details"
        Me.NsGroupBox3.TabIndex = 2
        Me.NsGroupBox3.Text = "NsGroupBox3"
        Me.NsGroupBox3.Title = "World of Warcraft Soundtrack"
        '
        'NsSeperator2
        '
        Me.NsSeperator2.Location = New System.Drawing.Point(3, 34)
        Me.NsSeperator2.Name = "NsSeperator2"
        Me.NsSeperator2.Size = New System.Drawing.Size(386, 10)
        Me.NsSeperator2.TabIndex = 1
        Me.NsSeperator2.Text = "NsSeperator2"
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.Color.Black
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 17
        Me.ListBox2.Location = New System.Drawing.Point(3, 42)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(386, 170)
        Me.ListBox2.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(568, 446)
        Me.Controls.Add(Me.OUT)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.NsGroupBox4)
        Me.Controls.Add(Me.NsGroupBox1)
        Me.Controls.Add(Me.NsTabControl1)
        Me.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "World of Warcraft | Patch: 1.12.1 (5876)"
        Me.NsGroupBox4.ResumeLayout(False)
        Me.NsGroupBox1.ResumeLayout(False)
        Me.NsTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.NsGroupBox5.ResumeLayout(False)
        Me.NsGroupBox5.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.gb_AU.ResumeLayout(False)
        Me.gb_AU.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.NsGroupBox2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WMP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NsGroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NsTabControl1 As NSTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents NsGroupBox1 As NSGroupBox
    Friend WithEvents NsLabel2 As NSLabel
    Friend WithEvents NsProgressBar1 As NSProgressBar
    Friend WithEvents NsLabel1 As NSLabel
    Friend WithEvents NsTextBox1 As NSTextBox
    Friend WithEvents NsLabel3 As NSLabel
    Friend WithEvents NsButton1 As NSButton
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents NsButton3 As NSButton
    Friend WithEvents NsLabel5 As NSLabel
    Friend WithEvents NsButton2 As NSButton
    Friend WithEvents NsLabel4 As NSLabel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents NsGroupBox2 As NSGroupBox
    Friend WithEvents NsSeperator1 As NSSeperator
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents NsButton6 As NSButton
    Friend WithEvents NsButton5 As NSButton
    Friend WithEvents NsButton4 As NSButton
    Friend WithEvents lbl_AddOn As Label
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents NsButton9 As NSButton
    Friend WithEvents NsButton8 As NSButton
    Friend WithEvents NsButton7 As NSButton
    Friend WithEvents NsGroupBox3 As NSGroupBox
    Friend WithEvents NsSeperator2 As NSSeperator
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents WMP As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Label3 As Label
    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents btn_Play1 As ButtonBlue
    Friend WithEvents Button2 As ButtonBlue
    Friend WithEvents NsGroupBox4 As NSGroupBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents NsGroupBox5 As NSGroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents NsTextBox2 As NSTextBox
    Friend WithEvents KachClazz1 As KachClazz
    Friend WithEvents gb_AU As NSGroupBox
    Friend WithEvents tb_UserPass As NSTextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents NsCheckBox1 As NSCheckBox
    Friend WithEvents btn_Play2 As ButtonBlue
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents OUT As TextBox
    Friend WithEvents Timer3 As Timer
End Class
