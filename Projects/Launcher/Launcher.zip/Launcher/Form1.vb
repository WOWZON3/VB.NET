﻿Imports System.IO
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dateiinhalt As String = My.Computer.FileSystem.ReadAllText(".\Data\deDE" & "\realmlist.wtf")
        NsTextBox1.Text = dateiinhalt.Replace("set realmlist ", "")
        For Each a As String In IO.Directory.GetDirectories(My.Computer.FileSystem.CurrentDirectory & "\Interface\AddOns\")
            Dim fi As New IO.FileInfo(a)
            ListBox1.Items.Add(fi.Name)
        Next
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Process.Start("WoW.exe")
            Me.Close()
        Catch ex As Exception
            MsgBox("Fehler! " & ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub NsButton1_Click(sender As Object, e As EventArgs) Handles NsButton1.Click
        Try
            Dim Writer As New StreamWriter(".\Data\deDE" & "\realmlist.wtf", False)
            Writer.Write("set realmlist " & NsTextBox1.Text)
            Writer.Close()
        Catch ex As Exception
            MsgBox("Fehler! " & ex.Message)
        End Try
    End Sub

    Private Sub NsButton2_Click(sender As Object, e As EventArgs) Handles NsButton2.Click
        Try
            Dim myTempPath As String = ".\Cache\WDB\deDE"
            System.IO.Directory.Delete(myTempPath, True)
            Label1.Visible = True
            Timer1.Start()
        Catch ex As Exception
            MsgBox("Das gewählte Verzeichnis ist leer und muss deshalb nicht geleert werden.")
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Visible = False
        Timer1.Stop()
    End Sub

    Private Sub NsButton3_Click(sender As Object, e As EventArgs) Handles NsButton3.Click
        If MessageBox.Show("Sollen die Einstellungen des Spiels wirklich gelöscht werden? Dies kann anschließend nicht mehr rückgängig gemacht werden.", "Konfigurationsdateien des Spiels löschen?", MessageBoxButtons.YesNo) _
             = Windows.Forms.DialogResult.Yes Then
            Try
                Dim myTempPath As String = ".\WTF"
                System.IO.Directory.Delete(myTempPath, True)
                Label2.Visible = True
                Timer2.Start()
            Catch ex As Exception
                MsgBox("Das gewählte Verzeichnis ist leer und muss deshalb nicht geleert werden.")
            End Try
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Label2.Visible = False
        My.Computer.FileSystem.CreateDirectory("WTF")
        Timer2.Stop()
    End Sub

    Private Sub NsButton4_Click(sender As Object, e As EventArgs) Handles NsButton4.Click
        Try
            Process.Start(lbl_AddOn.Text)
        Catch ex As Exception
            MsgBox("Fehler! " & ex.Message)
        End Try
    End Sub

    Private Sub NsButton5_Click(sender As Object, e As EventArgs) Handles NsButton5.Click
        If My.Computer.FileSystem.DirectoryExists(My.Computer.FileSystem.CurrentDirectory & "\BackUps\") = True Then
            Try
                My.Computer.FileSystem.CopyDirectory(My.Computer.FileSystem.CurrentDirectory & "\Interface\AddOns\" & lbl_AddOn.Text, My.Computer.FileSystem.CurrentDirectory & "\BackUps\" & lbl_AddOn.Text)
            Catch ex As Exception
                MsgBox("Fehler! " & ex.Message)
            End Try
        Else
            Try
                My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.CurrentDirectory & "\BackUps\")
                My.Computer.FileSystem.CopyDirectory(My.Computer.FileSystem.CurrentDirectory & "\Interface\AddOns\" & lbl_AddOn.Text, My.Computer.FileSystem.CurrentDirectory & "\BackUps\" & lbl_AddOn.Text)
            Catch ex As Exception
                MsgBox("Fehler! " & ex.Message)
            End Try
        End If
        ListBox1.Items.Clear()
        For Each a As String In IO.Directory.GetDirectories(My.Computer.FileSystem.CurrentDirectory & "\Interface\AddOns\")
            Dim fi As New IO.FileInfo(a)
            ListBox1.Items.Add(fi.Name)
        Next
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        lbl_AddOn.Text = ListBox1.SelectedItem
    End Sub

    Private Sub NsButton6_Click(sender As Object, e As EventArgs) Handles NsButton6.Click
        Try
            My.Computer.FileSystem.DeleteDirectory(".\Interface\AddOns\" & lbl_AddOn.Text, False)
        Catch ex As Exception
            MsgBox("Fehler! " & ex.Message)
        End Try
        ListBox1.Items.Clear()
        For Each a As String In IO.Directory.GetDirectories(My.Computer.FileSystem.CurrentDirectory & "\Interface\AddOns\")
            Dim fi As New IO.FileInfo(a)
            ListBox1.Items.Add(fi.Name)
        Next
    End Sub
End Class
