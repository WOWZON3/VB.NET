﻿Imports System.IO
Public Class frm_Settings
    Private Sub frm_Settings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim File1 As String = File.ReadAllText(".\Data\Vorlagen\Remote_rpi.dat")
        tb_RPI.Text = File1
    End Sub
    Private Sub NsButton1_Click(sender As Object, e As EventArgs) Handles NsButton1.Click
        Me.Close()
        frm_Main.Show()
    End Sub
    Private Sub NsButton2_Click(sender As Object, e As EventArgs) Handles NsButton2.Click
        tb_RPI.Text = tb_RPI.Text.Replace("%IP%", tb_Host.Text)
    End Sub

    Private Sub NsButton3_Click(sender As Object, e As EventArgs) Handles NsButton3.Click
        If SaveFileDialog1.ShowDialog = DialogResult.OK Then
            Dim Writer As New StreamWriter(SaveFileDialog1.FileName, False)
            Writer.Write(tb_RPI.Text)
            Writer.Close()
        End If
    End Sub
    Private Sub frm_Settings_Close(sender As Object, e As EventArgs) Handles MyBase.Closing
        frm_Main.Show()
    End Sub

    Private Sub NsButton4_Click(sender As Object, e As EventArgs) Handles NsButton4.Click
        NsButton4.Visible = False
        NsButton5.Visible = True
        NsTextBox1.Visible = True
    End Sub

    Private Sub NsButton5_Click(sender As Object, e As EventArgs) Handles NsButton5.Click
        NsButton4.Visible = True
        NsButton5.Visible = False
        NsTextBox1.Visible = False
        lbl_RDP1.Text = NsTextBox1.Text
        My.Settings.RDP1 = lbl_RDP1.Text
        My.Settings.Save()
    End Sub
End Class