﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Settings
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Settings))
        Me.NsTabControl1 = New Windows_Manager.NSTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.NsGroupBox1 = New Windows_Manager.NSGroupBox()
        Me.NsButton3 = New Windows_Manager.NSButton()
        Me.NsButton2 = New Windows_Manager.NSButton()
        Me.tb_Host = New Windows_Manager.NSTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tb_RPI = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.NsButton5 = New Windows_Manager.NSButton()
        Me.NsTextBox1 = New Windows_Manager.NSTextBox()
        Me.NsButton4 = New Windows_Manager.NSButton()
        Me.lbl_RPI = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NsButton1 = New Windows_Manager.NSButton()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.lbl_RDP1 = New System.Windows.Forms.Label()
        Me.NsTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.NsGroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'NsTabControl1
        '
        Me.NsTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.NsTabControl1.Controls.Add(Me.TabPage1)
        Me.NsTabControl1.Controls.Add(Me.TabPage2)
        Me.NsTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.NsTabControl1.ItemSize = New System.Drawing.Size(28, 115)
        Me.NsTabControl1.Location = New System.Drawing.Point(35, 31)
        Me.NsTabControl1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.NsTabControl1.Multiline = True
        Me.NsTabControl1.Name = "NsTabControl1"
        Me.NsTabControl1.SelectedIndex = 0
        Me.NsTabControl1.Size = New System.Drawing.Size(910, 555)
        Me.NsTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.NsTabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(119, 4)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TabPage1.Size = New System.Drawing.Size(787, 547)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "RDP Datei"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.NsGroupBox1)
        Me.Panel1.Controls.Add(Me.tb_RPI)
        Me.Panel1.Location = New System.Drawing.Point(3, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(781, 538)
        Me.Panel1.TabIndex = 1
        '
        'NsGroupBox1
        '
        Me.NsGroupBox1.Controls.Add(Me.lbl_RDP1)
        Me.NsGroupBox1.Controls.Add(Me.NsButton3)
        Me.NsGroupBox1.Controls.Add(Me.NsButton2)
        Me.NsGroupBox1.Controls.Add(Me.tb_Host)
        Me.NsGroupBox1.Controls.Add(Me.Label1)
        Me.NsGroupBox1.DrawSeperator = False
        Me.NsGroupBox1.Location = New System.Drawing.Point(19, 14)
        Me.NsGroupBox1.Name = "NsGroupBox1"
        Me.NsGroupBox1.Size = New System.Drawing.Size(749, 107)
        Me.NsGroupBox1.SubTitle = ""
        Me.NsGroupBox1.TabIndex = 2
        Me.NsGroupBox1.Text = "NsGroupBox1"
        Me.NsGroupBox1.Title = ""
        '
        'NsButton3
        '
        Me.NsButton3.Location = New System.Drawing.Point(621, 55)
        Me.NsButton3.Name = "NsButton3"
        Me.NsButton3.Size = New System.Drawing.Size(111, 32)
        Me.NsButton3.TabIndex = 3
        Me.NsButton3.Text = "     Erstellen"
        '
        'NsButton2
        '
        Me.NsButton2.Location = New System.Drawing.Point(621, 17)
        Me.NsButton2.Name = "NsButton2"
        Me.NsButton2.Size = New System.Drawing.Size(111, 32)
        Me.NsButton2.TabIndex = 2
        Me.NsButton2.Text = "  Übernehmen"
        '
        'tb_Host
        '
        Me.tb_Host.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.tb_Host.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Host.Location = New System.Drawing.Point(127, 16)
        Me.tb_Host.MaxLength = 32767
        Me.tb_Host.Multiline = False
        Me.tb_Host.Name = "tb_Host"
        Me.tb_Host.ReadOnly = False
        Me.tb_Host.Size = New System.Drawing.Size(211, 27)
        Me.tb_Host.TabIndex = 1
        Me.tb_Host.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.tb_Host.UseSystemPasswordChar = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Silver
        Me.Label1.Location = New System.Drawing.Point(16, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Remote Host:"
        '
        'tb_RPI
        '
        Me.tb_RPI.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.tb_RPI.ForeColor = System.Drawing.Color.DodgerBlue
        Me.tb_RPI.Location = New System.Drawing.Point(19, 138)
        Me.tb_RPI.Multiline = True
        Me.tb_RPI.Name = "tb_RPI"
        Me.tb_RPI.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tb_RPI.Size = New System.Drawing.Size(749, 381)
        Me.tb_RPI.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.NsButton5)
        Me.TabPage2.Controls.Add(Me.NsTextBox1)
        Me.TabPage2.Controls.Add(Me.NsButton4)
        Me.TabPage2.Controls.Add(Me.lbl_RPI)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Location = New System.Drawing.Point(119, 4)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TabPage2.Size = New System.Drawing.Size(787, 547)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Remote Host"
        '
        'NsButton5
        '
        Me.NsButton5.Location = New System.Drawing.Point(362, 23)
        Me.NsButton5.Name = "NsButton5"
        Me.NsButton5.Size = New System.Drawing.Size(89, 33)
        Me.NsButton5.TabIndex = 16
        Me.NsButton5.Text = " Speichern"
        Me.NsButton5.Visible = False
        '
        'NsTextBox1
        '
        Me.NsTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NsTextBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsTextBox1.Location = New System.Drawing.Point(136, 23)
        Me.NsTextBox1.MaxLength = 32767
        Me.NsTextBox1.Multiline = False
        Me.NsTextBox1.Name = "NsTextBox1"
        Me.NsTextBox1.ReadOnly = False
        Me.NsTextBox1.Size = New System.Drawing.Size(204, 27)
        Me.NsTextBox1.TabIndex = 15
        Me.NsTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.NsTextBox1.UseSystemPasswordChar = False
        Me.NsTextBox1.Visible = False
        '
        'NsButton4
        '
        Me.NsButton4.Location = New System.Drawing.Point(362, 23)
        Me.NsButton4.Name = "NsButton4"
        Me.NsButton4.Size = New System.Drawing.Size(89, 33)
        Me.NsButton4.TabIndex = 14
        Me.NsButton4.Text = " Bearbeiten"
        '
        'lbl_RPI
        '
        Me.lbl_RPI.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RPI.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RPI.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_RPI.Location = New System.Drawing.Point(136, 28)
        Me.lbl_RPI.Name = "lbl_RPI"
        Me.lbl_RPI.Size = New System.Drawing.Size(204, 22)
        Me.lbl_RPI.TabIndex = 13
        Me.lbl_RPI.Text = "..."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Silver
        Me.Label2.Location = New System.Drawing.Point(27, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 14)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Raspberry Pi 3:"
        '
        'NsButton1
        '
        Me.NsButton1.Location = New System.Drawing.Point(874, 611)
        Me.NsButton1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.NsButton1.Name = "NsButton1"
        Me.NsButton1.Size = New System.Drawing.Size(82, 40)
        Me.NsButton1.TabIndex = 1
        Me.NsButton1.Text = "   Zurück"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.CreatePrompt = True
        Me.SaveFileDialog1.DefaultExt = "rdp"
        Me.SaveFileDialog1.Filter = "Remote Desktop Datei|.rdp"
        '
        'lbl_RDP1
        '
        Me.lbl_RDP1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RDP1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_RDP1.Location = New System.Drawing.Point(127, 16)
        Me.lbl_RDP1.Name = "lbl_RDP1"
        Me.lbl_RDP1.Size = New System.Drawing.Size(211, 22)
        Me.lbl_RDP1.TabIndex = 10
        Me.lbl_RDP1.Text = "..."
        '
        'frm_Settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(969, 663)
        Me.Controls.Add(Me.NsButton1)
        Me.Controls.Add(Me.NsTabControl1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "frm_Settings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_Settings"
        Me.NsTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.NsGroupBox1.ResumeLayout(False)
        Me.NsGroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents NsTabControl1 As NSTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents NsButton1 As NSButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents NsGroupBox1 As NSGroupBox
    Friend WithEvents NsButton3 As NSButton
    Friend WithEvents NsButton2 As NSButton
    Friend WithEvents tb_Host As NSTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents tb_RPI As TextBox
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents Label2 As Label
    Friend WithEvents NsButton5 As NSButton
    Friend WithEvents NsTextBox1 As NSTextBox
    Friend WithEvents NsButton4 As NSButton
    Friend WithEvents lbl_RPI As Label
    Friend WithEvents lbl_RDP1 As Label
End Class
