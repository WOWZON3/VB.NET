﻿Namespace Windows
    Friend Class Forms
        Friend Shared Function MouseButtons() As Object
            Throw New NotImplementedException()
        End Function

        Friend Shared Function DrawMode() As Object
            Throw New NotImplementedException()
        End Function
    End Class
End Namespace
