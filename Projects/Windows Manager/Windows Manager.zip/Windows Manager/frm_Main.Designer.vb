﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Main
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Main))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lbl_IP = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_Username = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lbl_RPI2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbl_RPI1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lbl_RPI = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.NsButton3 = New Windows_Manager.NSButton()
        Me.NsButton2 = New Windows_Manager.NSButton()
        Me.NsCheckBox1 = New Windows_Manager.NSCheckBox()
        Me.NsGroupBox2 = New Windows_Manager.NSGroupBox()
        Me.NsLabel1 = New Windows_Manager.NSLabel()
        Me.NsOnOffBox1 = New Windows_Manager.NSOnOffBox()
        Me.NsGroupBox1 = New Windows_Manager.NSGroupBox()
        Me.NsSeperator1 = New Windows_Manager.NSSeperator()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.NsButton1 = New Windows_Manager.NSButton()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.NsGroupBox2.SuspendLayout()
        Me.NsGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.WebBrowser1)
        Me.Panel1.Location = New System.Drawing.Point(12, 465)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(155, 75)
        Me.Panel1.TabIndex = 1
        Me.Panel1.Visible = False
        '
        'Button4
        '
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Location = New System.Drawing.Point(98, 18)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(35, 35)
        Me.Button4.TabIndex = 5
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Location = New System.Drawing.Point(57, 18)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(35, 35)
        Me.Button3.TabIndex = 4
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Location = New System.Drawing.Point(16, 18)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(35, 35)
        Me.Button2.TabIndex = 3
        Me.Button2.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(319, 100)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScriptErrorsSuppressed = True
        Me.WebBrowser1.Size = New System.Drawing.Size(199, 194)
        Me.WebBrowser1.TabIndex = 0
        Me.WebBrowser1.Url = New System.Uri("http://nsradio.sytes.net/nsradio/", System.UriKind.Absolute)
        Me.WebBrowser1.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.lbl_IP)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.lbl_Username)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(12, 23)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(299, 113)
        Me.Panel2.TabIndex = 7
        '
        'lbl_IP
        '
        Me.lbl_IP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_IP.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_IP.Location = New System.Drawing.Point(128, 66)
        Me.lbl_IP.Name = "lbl_IP"
        Me.lbl_IP.Size = New System.Drawing.Size(150, 22)
        Me.lbl_IP.TabIndex = 10
        Me.lbl_IP.Text = "..."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Silver
        Me.Label2.Location = New System.Drawing.Point(43, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 14)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "IP Adresse:"
        '
        'lbl_Username
        '
        Me.lbl_Username.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Username.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_Username.Location = New System.Drawing.Point(128, 17)
        Me.lbl_Username.Name = "lbl_Username"
        Me.lbl_Username.Size = New System.Drawing.Size(150, 22)
        Me.lbl_Username.TabIndex = 9
        Me.lbl_Username.Text = "..."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Silver
        Me.Label1.Location = New System.Drawing.Point(13, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 14)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Angemeldet als:"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.NsCheckBox1)
        Me.Panel3.Controls.Add(Me.lbl_RPI)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.lbl_RPI2)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.lbl_RPI1)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Location = New System.Drawing.Point(15, 206)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(299, 197)
        Me.Panel3.TabIndex = 8
        '
        'lbl_RPI2
        '
        Me.lbl_RPI2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RPI2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_RPI2.Location = New System.Drawing.Point(113, 66)
        Me.lbl_RPI2.Name = "lbl_RPI2"
        Me.lbl_RPI2.Size = New System.Drawing.Size(165, 22)
        Me.lbl_RPI2.TabIndex = 10
        Me.lbl_RPI2.Text = "..."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Silver
        Me.Label4.Location = New System.Drawing.Point(27, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 14)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "IP Adresse:"
        '
        'lbl_RPI1
        '
        Me.lbl_RPI1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RPI1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_RPI1.Location = New System.Drawing.Point(113, 17)
        Me.lbl_RPI1.Name = "lbl_RPI1"
        Me.lbl_RPI1.Size = New System.Drawing.Size(165, 22)
        Me.lbl_RPI1.TabIndex = 9
        Me.lbl_RPI1.Text = "..."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Silver
        Me.Label6.Location = New System.Drawing.Point(27, 18)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 14)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "IP Adresse:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Silver
        Me.Label7.Location = New System.Drawing.Point(12, 173)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(179, 14)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Raspberry Pi Informationen"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Silver
        Me.Label3.Location = New System.Drawing.Point(601, 351)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 14)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "WebMin Panel:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Silver
        Me.Label5.Location = New System.Drawing.Point(598, 401)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(103, 14)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "User App Data:"
        '
        'lbl_RPI
        '
        Me.lbl_RPI.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RPI.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RPI.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lbl_RPI.Location = New System.Drawing.Point(113, 114)
        Me.lbl_RPI.Name = "lbl_RPI"
        Me.lbl_RPI.Size = New System.Drawing.Size(165, 22)
        Me.lbl_RPI.TabIndex = 12
        Me.lbl_RPI.Text = "..."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Silver
        Me.Label9.Location = New System.Drawing.Point(6, 115)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(101, 14)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Webmin Panel:"
        '
        'NsButton3
        '
        Me.NsButton3.Location = New System.Drawing.Point(707, 392)
        Me.NsButton3.Name = "NsButton3"
        Me.NsButton3.Size = New System.Drawing.Size(66, 32)
        Me.NsButton3.TabIndex = 13
        Me.NsButton3.Text = " Öffnen"
        '
        'NsButton2
        '
        Me.NsButton2.Location = New System.Drawing.Point(707, 343)
        Me.NsButton2.Name = "NsButton2"
        Me.NsButton2.Size = New System.Drawing.Size(66, 32)
        Me.NsButton2.TabIndex = 11
        Me.NsButton2.Text = " Öffnen"
        '
        'NsCheckBox1
        '
        Me.NsCheckBox1.Checked = False
        Me.NsCheckBox1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsCheckBox1.Location = New System.Drawing.Point(113, 144)
        Me.NsCheckBox1.Name = "NsCheckBox1"
        Me.NsCheckBox1.Size = New System.Drawing.Size(162, 23)
        Me.NsCheckBox1.TabIndex = 14
        Me.NsCheckBox1.Text = " Intern Öffnen"
        '
        'NsGroupBox2
        '
        Me.NsGroupBox2.Controls.Add(Me.NsLabel1)
        Me.NsGroupBox2.Controls.Add(Me.NsOnOffBox1)
        Me.NsGroupBox2.DrawSeperator = False
        Me.NsGroupBox2.Location = New System.Drawing.Point(333, 335)
        Me.NsGroupBox2.Name = "NsGroupBox2"
        Me.NsGroupBox2.Size = New System.Drawing.Size(199, 141)
        Me.NsGroupBox2.SubTitle = ""
        Me.NsGroupBox2.TabIndex = 6
        Me.NsGroupBox2.Text = "NsGroupBox2"
        Me.NsGroupBox2.Title = ""
        '
        'NsLabel1
        '
        Me.NsLabel1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel1.Location = New System.Drawing.Point(15, 16)
        Me.NsLabel1.Name = "NsLabel1"
        Me.NsLabel1.Size = New System.Drawing.Size(93, 23)
        Me.NsLabel1.TabIndex = 4
        Me.NsLabel1.Text = "NsLabel1"
        Me.NsLabel1.Value1 = "NS"
        Me.NsLabel1.Value2 = " Webradio"
        '
        'NsOnOffBox1
        '
        Me.NsOnOffBox1.Checked = False
        Me.NsOnOffBox1.Location = New System.Drawing.Point(114, 16)
        Me.NsOnOffBox1.MaximumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.MinimumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.Name = "NsOnOffBox1"
        Me.NsOnOffBox1.Size = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.TabIndex = 3
        Me.NsOnOffBox1.Text = "NsOnOffBox1"
        '
        'NsGroupBox1
        '
        Me.NsGroupBox1.Controls.Add(Me.NsSeperator1)
        Me.NsGroupBox1.Controls.Add(Me.Button28)
        Me.NsGroupBox1.Controls.Add(Me.Button29)
        Me.NsGroupBox1.Controls.Add(Me.Button30)
        Me.NsGroupBox1.Controls.Add(Me.Button31)
        Me.NsGroupBox1.Controls.Add(Me.Button32)
        Me.NsGroupBox1.Controls.Add(Me.Button33)
        Me.NsGroupBox1.Controls.Add(Me.Button34)
        Me.NsGroupBox1.Controls.Add(Me.Button35)
        Me.NsGroupBox1.Controls.Add(Me.Button20)
        Me.NsGroupBox1.Controls.Add(Me.Button21)
        Me.NsGroupBox1.Controls.Add(Me.Button22)
        Me.NsGroupBox1.Controls.Add(Me.Button23)
        Me.NsGroupBox1.Controls.Add(Me.Button24)
        Me.NsGroupBox1.Controls.Add(Me.Button25)
        Me.NsGroupBox1.Controls.Add(Me.Button26)
        Me.NsGroupBox1.Controls.Add(Me.Button27)
        Me.NsGroupBox1.Controls.Add(Me.Button12)
        Me.NsGroupBox1.Controls.Add(Me.Button13)
        Me.NsGroupBox1.Controls.Add(Me.Button14)
        Me.NsGroupBox1.Controls.Add(Me.Button15)
        Me.NsGroupBox1.Controls.Add(Me.Button16)
        Me.NsGroupBox1.Controls.Add(Me.Button17)
        Me.NsGroupBox1.Controls.Add(Me.Button18)
        Me.NsGroupBox1.Controls.Add(Me.Button19)
        Me.NsGroupBox1.Controls.Add(Me.Button11)
        Me.NsGroupBox1.Controls.Add(Me.Button10)
        Me.NsGroupBox1.Controls.Add(Me.Button9)
        Me.NsGroupBox1.Controls.Add(Me.Button8)
        Me.NsGroupBox1.Controls.Add(Me.Button7)
        Me.NsGroupBox1.Controls.Add(Me.Button6)
        Me.NsGroupBox1.Controls.Add(Me.Button5)
        Me.NsGroupBox1.Controls.Add(Me.Button1)
        Me.NsGroupBox1.DrawSeperator = False
        Me.NsGroupBox1.Location = New System.Drawing.Point(333, 22)
        Me.NsGroupBox1.Name = "NsGroupBox1"
        Me.NsGroupBox1.Size = New System.Drawing.Size(459, 288)
        Me.NsGroupBox1.SubTitle = "Anwendungen & Tools"
        Me.NsGroupBox1.TabIndex = 5
        Me.NsGroupBox1.Text = "NsGroupBox1"
        Me.NsGroupBox1.Title = "Schnellstart"
        '
        'NsSeperator1
        '
        Me.NsSeperator1.Location = New System.Drawing.Point(3, 39)
        Me.NsSeperator1.Name = "NsSeperator1"
        Me.NsSeperator1.Size = New System.Drawing.Size(453, 11)
        Me.NsSeperator1.TabIndex = 8
        Me.NsSeperator1.Text = "NsSeperator1"
        '
        'Button28
        '
        Me.Button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button28.Location = New System.Drawing.Point(386, 222)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(45, 45)
        Me.Button28.TabIndex = 33
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button29.Location = New System.Drawing.Point(335, 222)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(45, 45)
        Me.Button29.TabIndex = 32
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button30.Location = New System.Drawing.Point(284, 222)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(45, 45)
        Me.Button30.TabIndex = 31
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button31.Location = New System.Drawing.Point(233, 222)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(45, 45)
        Me.Button31.TabIndex = 30
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button32.Location = New System.Drawing.Point(182, 222)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(45, 45)
        Me.Button32.TabIndex = 29
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button33.Location = New System.Drawing.Point(131, 222)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(45, 45)
        Me.Button33.TabIndex = 28
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button34.Location = New System.Drawing.Point(80, 222)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(45, 45)
        Me.Button34.TabIndex = 27
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button35.Location = New System.Drawing.Point(29, 222)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(45, 45)
        Me.Button35.TabIndex = 26
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button20.Location = New System.Drawing.Point(386, 171)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(45, 45)
        Me.Button20.TabIndex = 25
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button21.Location = New System.Drawing.Point(335, 171)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(45, 45)
        Me.Button21.TabIndex = 24
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button22.Location = New System.Drawing.Point(284, 171)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(45, 45)
        Me.Button22.TabIndex = 23
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button23.Location = New System.Drawing.Point(233, 171)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(45, 45)
        Me.Button23.TabIndex = 22
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button24.Location = New System.Drawing.Point(182, 171)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(45, 45)
        Me.Button24.TabIndex = 21
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button25.Location = New System.Drawing.Point(131, 171)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(45, 45)
        Me.Button25.TabIndex = 20
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button26.Location = New System.Drawing.Point(80, 171)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(45, 45)
        Me.Button26.TabIndex = 19
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button27.Location = New System.Drawing.Point(29, 171)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(45, 45)
        Me.Button27.TabIndex = 18
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button12.Location = New System.Drawing.Point(386, 120)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(45, 45)
        Me.Button12.TabIndex = 17
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button13.Location = New System.Drawing.Point(335, 120)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(45, 45)
        Me.Button13.TabIndex = 16
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button14.Location = New System.Drawing.Point(284, 120)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(45, 45)
        Me.Button14.TabIndex = 15
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button15.Location = New System.Drawing.Point(233, 120)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(45, 45)
        Me.Button15.TabIndex = 14
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button16.Location = New System.Drawing.Point(182, 120)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(45, 45)
        Me.Button16.TabIndex = 13
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button17.Location = New System.Drawing.Point(131, 120)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(45, 45)
        Me.Button17.TabIndex = 12
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button18.Location = New System.Drawing.Point(80, 120)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(45, 45)
        Me.Button18.TabIndex = 11
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button19.Location = New System.Drawing.Point(29, 120)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(45, 45)
        Me.Button19.TabIndex = 10
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button11.Location = New System.Drawing.Point(386, 69)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(45, 45)
        Me.Button11.TabIndex = 9
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button10.Location = New System.Drawing.Point(335, 69)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 45)
        Me.Button10.TabIndex = 8
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button9.Location = New System.Drawing.Point(284, 69)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(45, 45)
        Me.Button9.TabIndex = 7
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button8.Location = New System.Drawing.Point(233, 69)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(45, 45)
        Me.Button8.TabIndex = 6
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button7.Location = New System.Drawing.Point(182, 69)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 45)
        Me.Button7.TabIndex = 5
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Location = New System.Drawing.Point(131, 69)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 45)
        Me.Button6.TabIndex = 4
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.Location = New System.Drawing.Point(80, 69)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 45)
        Me.Button5.TabIndex = 3
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Location = New System.Drawing.Point(29, 69)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(45, 45)
        Me.Button1.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.Button1, "Einstellungen öffnen")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'NsButton1
        '
        Me.NsButton1.Location = New System.Drawing.Point(714, 512)
        Me.NsButton1.Name = "NsButton1"
        Me.NsButton1.Size = New System.Drawing.Size(95, 37)
        Me.NsButton1.TabIndex = 0
        Me.NsButton1.Text = "   Beenden"
        '
        'frm_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(821, 561)
        Me.Controls.Add(Me.NsButton3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.NsButton2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.NsGroupBox2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.NsGroupBox1)
        Me.Controls.Add(Me.NsButton1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.MaximizeBox = False
        Me.Name = "frm_Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Windows Manager | Advanced System Management"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.NsGroupBox2.ResumeLayout(False)
        Me.NsGroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NsButton1 As NSButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents NsOnOffBox1 As NSOnOffBox
    Friend WithEvents NsLabel1 As NSLabel
    Friend WithEvents NsGroupBox1 As NSGroupBox
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents NsGroupBox2 As NSGroupBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lbl_Username As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents NsSeperator1 As NSSeperator
    Friend WithEvents lbl_IP As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents lbl_RPI2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lbl_RPI1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents NsButton2 As NSButton
    Friend WithEvents NsButton3 As NSButton
    Friend WithEvents Label5 As Label
    Friend WithEvents lbl_RPI As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents NsCheckBox1 As NSCheckBox
    Friend WithEvents ToolTip1 As ToolTip
End Class
